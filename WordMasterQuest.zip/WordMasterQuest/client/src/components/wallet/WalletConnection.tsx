import { useState, useEffect } from 'react';
import { useGameStore } from '@/lib/stores/useGameStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
// Implementación personalizada en lugar de usar TonConnectButton
import { tonConnectUI } from '@/lib/tonconnect';

// TON Connect Wallet component
export function WalletConnection() {
  const [withdrawAmount, setWithdrawAmount] = useState(0);
  const [depositAmount, setDepositAmount] = useState(0);
  const [showWithdrawDialog, setShowWithdrawDialog] = useState(false);
  const [showDepositDialog, setShowDepositDialog] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  
  const balance = useGameStore((state) => state.balance);
  const addBalance = useGameStore((state) => state.addBalance);
  
  // Listen for wallet connection changes
  useEffect(() => {
    const unsubscribe = tonConnectUI.onStatusChange(wallet => {
      if (wallet) {
        setIsConnected(true);
        if (wallet.account?.address) {
          setWalletAddress(wallet.account.address);
        }
      } else {
        setIsConnected(false);
        setWalletAddress(null);
      }
    });
    
    return () => {
      unsubscribe();
    };
  }, []);

  // Handle TON deposit (simulated for now)
  const handleDeposit = () => {
    if (depositAmount <= 0) {
      toast.error('Vui lòng nhập số lượng TON hợp lệ');
      return;
    }

    // Simulate deposit by adding to game balance
    addBalance(depositAmount);
    toast.success(`Đã nạp thành công ${depositAmount} TON!`);
    setDepositAmount(0);
    setShowDepositDialog(false);
  };

  // Handle TON withdrawal (simulated for now)
  const handleWithdraw = () => {
    if (withdrawAmount <= 0) {
      toast.error('Vui lòng nhập số lượng TON hợp lệ');
      return;
    }

    if (withdrawAmount > balance) {
      toast.error('Số dư không đủ');
      return;
    }

    // Simulate withdrawal by deducting from game balance
    addBalance(-withdrawAmount);
    toast.success(`Đã rút thành công ${withdrawAmount} TON!`);
    setWithdrawAmount(0);
    setShowWithdrawDialog(false);
  };

  // Format the wallet address for display
  const formatWalletAddress = (address: string | null) => {
    if (!address) return 'Not connected';
    return `${address.slice(0, 8)}...${address.slice(-6)}`;
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent mb-2">Ví TON của bạn</h2>
        <p className="text-gray-600">Kết nối ví TON để nạp và rút tiền từ trò chơi</p>
      </div>
      
      <Tabs defaultValue="wallet" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-1">
          <TabsTrigger value="wallet" className="rounded-lg data-[state=active]:bg-white">
            Ví của bạn
          </TabsTrigger>
          <TabsTrigger value="transactions" className="rounded-lg data-[state=active]:bg-white">
            Giao dịch
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="wallet" className="mt-4">
          <Card className="bg-white/90 backdrop-blur-lg shadow-lg border-0 rounded-2xl overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-purple-100 to-blue-100 pb-3">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-xl font-medium text-gray-800">Thông tin ví</CardTitle>
                  <CardDescription>Quản lý ví TON của bạn</CardDescription>
                </div>
                <div className="flex justify-center">
                  <Button 
                    onClick={() => tonConnectUI.openModal()}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 text-white border-none hover:opacity-90 rounded-full"
                  >
                    {isConnected ? 'Quản lý ví' : 'Kết nối ví TON'}
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="p-4 flex flex-col gap-6">
                {/* Wallet Info Panel */}
                <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-6 rounded-xl border border-purple-100 shadow-sm">
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold text-purple-800 mb-1">Thông tin ví TON</h3>
                    {isConnected ? (
                      <p className="text-sm text-gray-600">Ví của bạn đã được kết nối thành công</p>
                    ) : (
                      <p className="text-sm text-gray-600">Kết nối ví TON để thực hiện các giao dịch</p>
                    )}
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Trạng thái:</span>
                      {isConnected ? (
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          <span className="w-2 h-2 rounded-full bg-green-600 mr-1.5"></span>
                          Đã kết nối
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                          <span className="w-2 h-2 rounded-full bg-gray-500 mr-1.5"></span>
                          Chưa kết nối
                        </span>
                      )}
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Địa chỉ ví:</span>
                      <span className="text-sm font-mono bg-white px-3 py-1 rounded-lg border border-gray-200">
                        {formatWalletAddress(walletAddress)}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Số dư trong game:</span>
                      <span className="text-sm font-medium bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                        {balance.toFixed(4)} TON
                      </span>
                    </div>
                  </div>
                </div>
                
                {/* Buttons Panel */}
                <div className="flex flex-col md:flex-row gap-3 justify-center">
                  <Dialog open={showDepositDialog} onOpenChange={setShowDepositDialog}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="bg-gradient-to-r from-emerald-500 to-green-500 text-white border-none hover:opacity-90 rounded-full px-6 w-full flex items-center justify-center gap-2"
                        disabled={!isConnected}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                          <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                        Nạp TON
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] bg-white rounded-xl border-0 shadow-xl">
                      <DialogHeader>
                        <DialogTitle className="text-xl font-bold text-green-600">Nạp TON</DialogTitle>
                        <DialogDescription>
                          Nhập số lượng TON bạn muốn nạp vào tài khoản game.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="deposit-amount" className="text-right">
                            Số lượng
                          </Label>
                          <Input
                            id="deposit-amount"
                            type="number"
                            min="0.1"
                            step="0.1"
                            className="col-span-3"
                            value={depositAmount || ''}
                            onChange={(e) => setDepositAmount(parseFloat(e.target.value) || 0)}
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setShowDepositDialog(false)} className="rounded-full">
                          Hủy
                        </Button>
                        <Button onClick={handleDeposit} className="bg-gradient-to-r from-emerald-500 to-green-500 rounded-full">
                          Nạp TON
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={showWithdrawDialog} onOpenChange={setShowWithdrawDialog}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white border-none hover:opacity-90 rounded-full px-6 w-full flex items-center justify-center gap-2"
                        disabled={!isConnected}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M12 2v8"></path>
                          <path d="M5 5.3l7-3.1 7 3.1"></path>
                          <path d="M5 10l7 3.1 7-3.1"></path>
                          <path d="M5 14.7l7 3.1 7-3.1"></path>
                          <path d="M5 19.4l7 3.1 7-3.1"></path>
                        </svg>
                        Rút TON
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] bg-white rounded-xl border-0 shadow-xl">
                      <DialogHeader>
                        <DialogTitle className="text-xl font-bold text-blue-600">Rút TON</DialogTitle>
                        <DialogDescription>
                          Nhập số lượng TON bạn muốn rút về ví.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="withdraw-amount" className="text-right">
                            Số lượng
                          </Label>
                          <Input
                            id="withdraw-amount"
                            type="number"
                            min="0.1"
                            max={balance}
                            step="0.1"
                            className="col-span-3"
                            value={withdrawAmount || ''}
                            onChange={(e) => setWithdrawAmount(parseFloat(e.target.value) || 0)}
                          />
                        </div>
                        <div className="col-span-4 text-sm text-gray-500 text-right">
                          Số dư khả dụng: {balance.toFixed(4)} TON
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setShowWithdrawDialog(false)} className="rounded-full">
                          Hủy
                        </Button>
                        <Button onClick={handleWithdraw} className="bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full">
                          Rút TON
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                
                {/* Notes Panel */}
                <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-xl border border-purple-100">
                  <h3 className="text-sm font-bold text-purple-700 mb-3">Lưu ý quan trọng</h3>
                  <ul className="space-y-2 text-xs text-gray-700">
                    <li className="flex items-start gap-2">
                      <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-5 h-5 flex-shrink-0 mt-0.5 text-xs">!</span>
                      <span>Mỗi giao dịch rút tiền sẽ mất phí gas (khoảng 0.05 TON)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-5 h-5 flex-shrink-0 mt-0.5 text-xs">!</span>
                      <span>Hãy đảm bảo bạn đang kết nối với ví đúng trước khi thực hiện giao dịch</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="transactions" className="mt-4">
          <Card className="bg-white/90 backdrop-blur-lg shadow-lg border-0 rounded-2xl overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-purple-100 to-blue-100 pb-3">
              <CardTitle className="text-xl font-medium text-gray-800">Lịch sử giao dịch</CardTitle>
              <CardDescription>Quản lý các giao dịch nạp và rút TON của bạn</CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="p-4">
                {/* Empty state for transactions */}
                <div className="bg-gray-50 rounded-xl p-8 text-center">
                  <div className="flex justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-gray-300">
                      <rect x="2" y="5" width="20" height="14" rx="2"></rect>
                      <line x1="2" y1="10" x2="22" y2="10"></line>
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-700 mb-2">Chưa có giao dịch nào</h3>
                  <p className="text-sm text-gray-500 mb-6">Khi bạn thực hiện giao dịch nạp hoặc rút TON, chúng sẽ hiển thị ở đây</p>
                  
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Button 
                      variant="outline" 
                      onClick={() => setShowDepositDialog(true)}
                      className="rounded-full border-purple-200 text-purple-700 hover:bg-purple-50 hover:text-purple-800"
                      disabled={!isConnected}
                    >
                      Nạp TON ngay
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Global notification about daily earnings at bottom */}
      <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-4 rounded-xl border border-blue-100">
        <div className="flex items-start gap-3">
          <div className="bg-blue-100 text-blue-700 rounded-full p-2 flex items-center justify-center flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
          </div>
          <div>
            <h3 className="text-md font-bold text-blue-800 mb-1">Thu nhập hằng ngày</h3>
            <p className="text-sm text-gray-700">
              Tiền kiếm được từ mèo sẽ tự động được cộng vào số dư trong game của bạn vào lúc <strong className="text-blue-700">2:00 sáng (UTC+7)</strong> mỗi ngày.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default WalletConnection;