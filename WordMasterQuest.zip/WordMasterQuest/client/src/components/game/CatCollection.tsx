import React, { useState } from 'react';
import { useGameStore } from '@/lib/stores/useGameStore';
import Cat from './Cat';
import { Button } from '../ui/button';
import { CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';

const CATS_PER_PAGE = 8;

const CatCollection: React.FC = () => {
  const cats = useGameStore((state) => state.cats);
  const [currentPage, setCurrentPage] = useState(1);
  const [rarityFilter, setRarityFilter] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'earnings'>('newest');

  // Apply filters and sorting
  const filteredCats = cats
    .filter(cat => !rarityFilter || cat.rarity === rarityFilter)
    .sort((a, b) => {
      if (sortBy === 'newest') return b.acquiredAt - a.acquiredAt;
      if (sortBy === 'oldest') return a.acquiredAt - b.acquiredAt;
      return b.earnPerDay - a.earnPerDay; // earnings (high to low)
    });

  // Calculate pagination
  const totalPages = Math.ceil(filteredCats.length / CATS_PER_PAGE);
  const paginatedCats = filteredCats.slice(
    (currentPage - 1) * CATS_PER_PAGE, 
    currentPage * CATS_PER_PAGE
  );

  // Calculate total earnings
  const totalEarningsPerDay = cats.reduce((total, cat) => total + cat.earnPerDay, 0);

  // Calculate rarity count
  const rarityCount = cats.reduce((acc, cat) => {
    acc[cat.rarity] = (acc[cat.rarity] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div>
      <CardHeader>
        <div className="flex justify-between items-center flex-wrap gap-4">
          <div>
            <CardTitle>Your Cat Collection</CardTitle>
            <CardDescription>
              You have {cats.length} cats earning {totalEarningsPerDay.toFixed(4)} TON per day
            </CardDescription>
          </div>
          
          <div className="flex gap-2">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">Sort by:</span>
              <select 
                className="bg-white border rounded px-2 py-1 text-sm"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest' | 'earnings')}
              >
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
                <option value="earnings">Earnings</option>
              </select>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">Filter:</span>
              <select 
                className="bg-white border rounded px-2 py-1 text-sm"
                value={rarityFilter || ''}
                onChange={(e) => setRarityFilter(e.target.value || null)}
              >
                <option value="">All</option>
                <option value="Common">Common</option>
                <option value="Rare">Rare</option>
                <option value="Epic">Epic</option>
                <option value="Legendary">Legendary</option>
                <option value="Mythic">Mythic</option>
              </select>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {cats.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-xl font-semibold mb-2">No cats yet!</h3>
            <p className="text-gray-500 mb-6">Head to the shop to buy your first egg and collect cats.</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {paginatedCats.map((cat) => (
                <Cat key={cat.id} cat={cat} />
              ))}
            </div>
            
            {/* Pagination controls */}
            {totalPages > 1 && (
              <div className="flex justify-center mt-8">
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  >
                    Previous
                  </Button>
                  
                  <span className="text-sm">
                    Page {currentPage} of {totalPages}
                  </span>
                  
                  <Button 
                    variant="outline" 
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
            
            {/* Rarity distribution */}
            <div className="mt-8 border-t pt-4">
              <h3 className="text-lg font-semibold mb-2">Your collection stats</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                <div className="bg-gray-100 rounded p-2 text-center">
                  <div className="font-semibold">Common</div>
                  <div>{rarityCount['Common'] || 0}</div>
                </div>
                <div className="bg-blue-100 rounded p-2 text-center">
                  <div className="font-semibold">Rare</div>
                  <div>{rarityCount['Rare'] || 0}</div>
                </div>
                <div className="bg-purple-100 rounded p-2 text-center">
                  <div className="font-semibold">Epic</div>
                  <div>{rarityCount['Epic'] || 0}</div>
                </div>
                <div className="bg-amber-100 rounded p-2 text-center">
                  <div className="font-semibold">Legendary</div>
                  <div>{rarityCount['Legendary'] || 0}</div>
                </div>
                <div className="bg-rose-100 rounded p-2 text-center">
                  <div className="font-semibold">Mythic</div>
                  <div>{rarityCount['Mythic'] || 0}</div>
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </div>
  );
};

export default CatCollection;
