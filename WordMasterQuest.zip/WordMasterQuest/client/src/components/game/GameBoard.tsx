import { useState, useEffect } from 'react';
import { useAudio } from '@/lib/stores/useAudio';
import { useGameStore } from '@/lib/stores/useGameStore';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Shop from './Shop';
import CatCollection from './CatCollection';
import Dashboard from './Dashboard';
import EggOpeningAnimation from './EggOpeningAnimation';
import WalletConnection from '../wallet/WalletConnection';
import { toast } from 'sonner';
import { tonConnectUI } from '@/lib/tonconnect';

type Tab = 'shop' | 'collection' | 'dashboard' | 'wallet';

const GameBoard = () => {
  const [activeTab, setActiveTab] = useState<Tab>('shop');
  const [showOpeningAnimation, setShowOpeningAnimation] = useState(false);
  const [eggToOpen, setEggToOpen] = useState<string | null>(null);
  const [userConnected, setUserConnected] = useState(false);
  const [userName, setUserName] = useState('Người chơi');
  const [userAvatar, setUserAvatar] = useState('');
  
  const backgroundMusic = useAudio((state) => state.backgroundMusic);
  const isMuted = useAudio((state) => state.isMuted);
  const toggleMute = useAudio((state) => state.toggleMute);
  
  const balance = useGameStore((state) => state.balance);
  const earnings = useGameStore((state) => state.totalEarnings);
  const cats = useGameStore((state) => state.cats);
  const addEarnings = useGameStore((state) => state.addEarnings);

  // This effect runs once when the component mounts
  useEffect(() => {
    // TON Connect UI will initialize automatically
    console.log("TON Connect UI is ready");
    
    // Listen to TON Connect wallet connection changes
    const unsubscribe = tonConnectUI.onStatusChange(wallet => {
      if (wallet) {
        setUserConnected(true);
        // Use TON Connect info to get user details
        // In a real app, these would come from Telegram via TON Connect
        // For now, we'll just show a default with a connected status
        setUserName('Người chơi TON');
        setUserAvatar('');
      } else {
        setUserConnected(false);
        setUserName('Người chơi');
        setUserAvatar('');
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleOpenEgg = (eggType: string) => {
    setEggToOpen(eggType);
    setShowOpeningAnimation(true);
  };

  const handleOpenAnimationComplete = () => {
    setShowOpeningAnimation(false);
    setEggToOpen(null);
  };

  // Function to check if it's payout time (2:00 AM UTC+7)
  const isPayoutTime = () => {
    const now = new Date();
    // Convert to UTC+7 time
    const utcPlus7Hours = now.getUTCHours() + 7;
    const hours = utcPlus7Hours % 24; // Handle day overflow
    const minutes = now.getUTCMinutes();
    
    // Check if it's 2:00 AM UTC+7 (with a 5-minute window for demo purposes)
    return (hours === 2 && minutes < 5);
  };

  // Daily earnings simulation
  useEffect(() => {
    // In production, this would check once daily at specific time (2:00 AM UTC+7)
    // For development, we check every minute and simulate the payout
    const earningsInterval = setInterval(() => {
      // For demo, we'll allow the payout to happen every minute
      // In production, we'd check isPayoutTime() here
      const shouldPayout = true; // For demo, always pay. In production: isPayoutTime()
      
      if (shouldPayout) {
        const totalDailyEarnings = cats.reduce((total, cat) => total + cat.earnPerDay, 0);
        if (totalDailyEarnings > 0) {
          addEarnings(totalDailyEarnings);
          toast.success(`Đã trả ${totalDailyEarnings.toFixed(4)} TON từ những chú mèo của bạn!`);
        }
      }
    }, 60000); // Every minute for demonstration
    
    return () => clearInterval(earningsInterval);
  }, [cats, addEarnings]);

  // Start background music when component mounts
  useEffect(() => {
    if (backgroundMusic && !isMuted) {
      backgroundMusic.play().catch(error => {
        console.log("Background music play prevented:", error);
      });
    }
    
    return () => {
      if (backgroundMusic) {
        backgroundMusic.pause();
      }
    };
  }, [backgroundMusic, isMuted]);

  return (
    <div className="w-full h-full flex flex-col bg-gradient-to-br from-purple-700 to-blue-500 overflow-hidden">
      {/* Header with game info */}
      <div className="w-full p-4 flex justify-between items-center bg-black/20 backdrop-blur-md rounded-b-2xl shadow-lg">
        <div className="flex items-center gap-3">
          {/* User profile area */}
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10 border-2 border-white/30 ring-2 ring-purple-500/20">
              {userAvatar ? (
                <AvatarImage src={userAvatar} alt={userName} />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-purple-500 to-blue-600 text-white">
                  {userName.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-white/80">Xin chào,</span>
              <span className="text-base font-bold text-white">{userName}</span>
            </div>
          </div>
          
          <div className="hidden sm:block h-8 w-px bg-white/20 mx-2"></div>
          
          <h1 className="hidden sm:block text-2xl font-bold text-white">TON Cat Eggs</h1>
        </div>
        
        <div className="flex items-center gap-4 md:gap-6">
          <div className="flex flex-col items-end">
            <span className="text-xs text-white/70">Số dư</span>
            <span className="text-sm md:text-base font-bold text-white">{balance.toFixed(4)} TON</span>
          </div>
          
          <div className="flex flex-col items-end">
            <span className="text-xs text-white/70">Thu nhập</span>
            <span className="text-sm md:text-base font-bold text-white">{cats.reduce((total, cat) => total + cat.earnPerDay, 0).toFixed(4)} TON/ngày</span>
          </div>
          
          <Button 
            variant="ghost" 
            className="rounded-full w-8 h-8 md:w-10 md:h-10 text-white hover:bg-white/20 p-0"
            onClick={toggleMute}
          >
            {isMuted ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <line x1="23" y1="9" x2="17" y2="15" />
                <line x1="17" y1="9" x2="23" y2="15" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
              </svg>
            )}
          </Button>
        </div>
      </div>
      
      {/* Tab navigation */}
      <div className="flex justify-center py-2 mt-2">
        <div className="px-4 py-1 bg-white/10 backdrop-blur-md rounded-full flex gap-1 shadow-lg">
          <Button
            variant="ghost"
            className={`rounded-full px-6 py-2 transition-all duration-300 ${
              activeTab === 'shop' 
                ? 'bg-white text-purple-700 shadow-md' 
                : 'text-white hover:bg-white/20'
            }`}
            onClick={() => setActiveTab('shop')}
          >
            Shop
          </Button>
          <Button
            variant="ghost"
            className={`rounded-full px-6 py-2 transition-all duration-300 ${
              activeTab === 'collection' 
                ? 'bg-white text-purple-700 shadow-md' 
                : 'text-white hover:bg-white/20'
            }`}
            onClick={() => setActiveTab('collection')}
          >
            Collection
          </Button>
          <Button
            variant="ghost"
            className={`rounded-full px-6 py-2 transition-all duration-300 ${
              activeTab === 'dashboard' 
                ? 'bg-white text-purple-700 shadow-md' 
                : 'text-white hover:bg-white/20'
            }`}
            onClick={() => setActiveTab('dashboard')}
          >
            Dashboard
          </Button>
          <Button
            variant="ghost"
            className={`rounded-full px-6 py-2 transition-all duration-300 ${
              activeTab === 'wallet' 
                ? 'bg-white text-purple-700 shadow-md' 
                : 'text-white hover:bg-white/20'
            }`}
            onClick={() => setActiveTab('wallet')}
          >
            Wallet
          </Button>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 overflow-y-auto p-4 pt-2">
        <Card className="w-full h-full max-w-6xl mx-auto bg-white/90 backdrop-blur-md rounded-2xl shadow-xl border-0 overflow-hidden">
          <div className="p-6 h-full overflow-y-auto">
            {activeTab === 'shop' && <Shop onOpenEgg={handleOpenEgg} />}
            {activeTab === 'collection' && <CatCollection />}
            {activeTab === 'dashboard' && <Dashboard />}
            {activeTab === 'wallet' && <WalletConnection />}
          </div>
        </Card>
      </div>
      
      {/* Egg opening animation overlay */}
      {showOpeningAnimation && eggToOpen && (
        <EggOpeningAnimation eggType={eggToOpen} onComplete={handleOpenAnimationComplete} />
      )}
    </div>
  );
};

export default GameBoard;
