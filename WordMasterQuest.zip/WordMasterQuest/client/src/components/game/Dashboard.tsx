import React from 'react';
import { useGameStore } from '@/lib/stores/useGameStore';
import { CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';

const Dashboard: React.FC = () => {
  const cats = useGameStore((state) => state.cats);
  const balance = useGameStore((state) => state.balance);
  const totalEarnings = useGameStore((state) => state.totalEarnings);
  const eggsOpened = useGameStore((state) => state.eggsOpened);
  
  // Calculate some statistics
  const dailyEarnings = cats.reduce((total, cat) => total + cat.earnPerDay, 0);
  
  // Count cats by rarity
  const catsByRarity = cats.reduce((acc, cat) => {
    acc[cat.rarity] = (acc[cat.rarity] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  // Calculate average earnings per cat
  const avgEarningsPerCat = cats.length 
    ? cats.reduce((total, cat) => total + cat.earnPerDay, 0) / cats.length 
    : 0;

  // Calculate eggs opened by type
  const eggsByType = Object.entries(eggsOpened).map(([type, count]) => ({
    type,
    count
  }));

  // Calculate collection completion stats
  const totalPossibleCats = 22; // based on game data
  const completionPercentage = Math.floor((cats.length / totalPossibleCats) * 100);
  
  return (
    <div>
      <CardHeader>
        <CardTitle>Dashboard</CardTitle>
        <CardDescription>View your game statistics and progress</CardDescription>
      </CardHeader>
      
      <CardContent>
        {/* Main statistics cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="text-sm text-blue-700 font-medium">Total Cats</h3>
            <div className="text-2xl font-bold">{cats.length}</div>
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg">
            <h3 className="text-sm text-green-700 font-medium">Daily Earnings</h3>
            <div className="text-2xl font-bold">{dailyEarnings.toFixed(4)} TON</div>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg">
            <h3 className="text-sm text-purple-700 font-medium">Current Balance</h3>
            <div className="text-2xl font-bold">{balance.toFixed(4)} TON</div>
          </div>
          
          <div className="bg-amber-50 p-4 rounded-lg">
            <h3 className="text-sm text-amber-700 font-medium">Eggs Opened</h3>
            <div className="text-2xl font-bold">
              {Object.values(eggsOpened).reduce((a, b) => a + b, 0)}
            </div>
          </div>
        </div>
        
        {/* Cat collection by rarity */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Cat Collection by Rarity</h3>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
            <div className="bg-gray-100 p-3 rounded-lg text-center">
              <div className="font-medium">Common</div>
              <div className="text-xl font-bold">{catsByRarity['Common'] || 0}</div>
            </div>
            
            <div className="bg-blue-100 p-3 rounded-lg text-center">
              <div className="font-medium">Rare</div>
              <div className="text-xl font-bold">{catsByRarity['Rare'] || 0}</div>
            </div>
            
            <div className="bg-purple-100 p-3 rounded-lg text-center">
              <div className="font-medium">Epic</div>
              <div className="text-xl font-bold">{catsByRarity['Epic'] || 0}</div>
            </div>
            
            <div className="bg-amber-100 p-3 rounded-lg text-center">
              <div className="font-medium">Legendary</div>
              <div className="text-xl font-bold">{catsByRarity['Legendary'] || 0}</div>
            </div>
            
            <div className="bg-rose-100 p-3 rounded-lg text-center">
              <div className="font-medium">Mythic</div>
              <div className="text-xl font-bold">{catsByRarity['Mythic'] || 0}</div>
            </div>
          </div>
        </div>
        
        {/* Earnings statistics */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Earnings Statistics</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm text-gray-500 mb-1">Total Earnings</h4>
              <div className="text-xl font-bold">{totalEarnings.toFixed(4)} TON</div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm text-gray-500 mb-1">Average per Cat</h4>
              <div className="text-xl font-bold">{avgEarningsPerCat.toFixed(4)} TON/day</div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm text-gray-500 mb-1">Return on Investment</h4>
              <div className="text-xl font-bold">
                {dailyEarnings > 0 
                  ? `${Math.floor(totalEarnings / dailyEarnings)} days` 
                  : '-'}
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-lg border border-purple-100">
              <h4 className="text-sm text-purple-700 mb-1">Payout Time</h4>
              <div className="text-xl font-bold text-purple-800">2:00 AM (UTC+7)</div>
              <p className="text-xs text-gray-600 mt-1">Daily earnings are paid at this time</p>
            </div>
          </div>
        </div>
        
        {/* Eggs opened by type */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Eggs Opened by Type</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {eggsByType.map(egg => (
              <div key={egg.type} className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm text-gray-500 mb-1 capitalize">{egg.type} Eggs</h4>
                <div className="text-xl font-bold">{egg.count}</div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Collection progress */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Collection Progress</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between mb-2">
              <span>Progress</span>
              <span>{completionPercentage}%</span>
            </div>
            <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-500 rounded-full"
                style={{ width: `${completionPercentage}%` }}
              ></div>
            </div>
            <div className="text-sm text-gray-500 mt-2">
              {cats.length} of {totalPossibleCats} cats collected
            </div>
          </div>
        </div>
      </CardContent>
    </div>
  );
};

export default Dashboard;
