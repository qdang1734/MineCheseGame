import React from 'react';
import { CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import Egg from './Egg';
import { useGameStore } from '@/lib/stores/useGameStore';
import { Button } from '../ui/button';
import { toast } from 'sonner';

interface ShopProps {
  onOpenEgg: (eggType: string) => void;
}

const Shop: React.FC<ShopProps> = ({ onOpenEgg }) => {
  const balance = useGameStore((state) => state.balance);
  const addBalance = useGameStore((state) => state.addBalance);

  const handleAddTest = () => {
    addBalance(10);
    toast.success("Added 10 TON for testing");
  };

  return (
    <div>
      <CardHeader className="pb-2">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">Egg Shop</CardTitle>
            <CardDescription className="text-gray-600">Buy eggs to hatch adorable cats!</CardDescription>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-sm text-right">
              <div className="text-gray-500">Your Balance</div>
              <div className="font-bold text-purple-700">{balance.toFixed(4)} TON</div>
            </div>
            <Button 
              onClick={handleAddTest} 
              variant="outline" 
              size="sm"
              className="bg-gradient-to-r from-purple-500 to-blue-500 text-white border-0 hover:opacity-90 rounded-full px-4"
            >
              + Add 10 TON (Test)
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Egg type="mini" onOpenEgg={onOpenEgg} />
          <Egg type="starter" onOpenEgg={onOpenEgg} />
          <Egg type="pro" onOpenEgg={onOpenEgg} />
          <Egg type="genesis" onOpenEgg={onOpenEgg} />
        </div>
        
        <div className="mt-8 bg-gradient-to-r from-purple-50 to-blue-50 p-6 rounded-xl shadow-sm border border-purple-100">
          <h3 className="text-lg font-bold text-purple-700 mb-3">How it works</h3>
          <ul className="space-y-3 text-sm text-gray-700">
            <li className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-6 h-6 flex-shrink-0">1</span>
              <span>Buy eggs using TON tokens to get adorable cats</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-6 h-6 flex-shrink-0">2</span>
              <span>Each cat generates TON tokens daily based on their rarity</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-6 h-6 flex-shrink-0">3</span>
              <span>Rarer cats generate more TON tokens</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-6 h-6 flex-shrink-0">4</span>
              <span>Collect cats to increase your daily earnings</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-700 rounded-full p-1 flex items-center justify-center w-6 h-6 flex-shrink-0">5</span>
              <span>Daily earnings are automatically added to your balance</span>
            </li>
          </ul>
        </div>
      </CardContent>
    </div>
  );
};

export default Shop;
