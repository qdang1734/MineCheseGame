import React from 'react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Cat as CatType } from '@/lib/stores/useGameStore';

interface CatProps {
  cat: CatType;
}

const Cat: React.FC<CatProps> = ({ cat }) => {
  // Helper to get rarity background color
  const getRarityColor = () => {
    switch (cat.rarity) {
      case 'Common':
        return 'bg-gray-50 border-gray-200';
      case 'Rare':
        return 'bg-blue-50 border-blue-200';
      case 'Epic':
        return 'bg-purple-50 border-purple-200';
      case 'Legendary':
        return 'bg-amber-50 border-amber-200';
      case 'Mythic':
        return 'bg-rose-50 border-rose-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  // Helper to get rarity badge color
  const getRarityBadgeColor = () => {
    switch (cat.rarity) {
      case 'Common':
        return 'bg-gray-200 text-gray-800';
      case 'Rare':
        return 'bg-blue-200 text-blue-800';
      case 'Epic':
        return 'bg-purple-200 text-purple-800';
      case 'Legendary':
        return 'bg-amber-200 text-amber-800';
      case 'Mythic':
        return 'bg-rose-200 text-rose-800';
      default:
        return 'bg-gray-200 text-gray-800';
    }
  };

  const getSvgPath = () => {
    switch (cat.rarity) {
      case 'Common':
        return '/src/assets/cats/common-cat.svg';
      case 'Rare':
        return '/src/assets/cats/rare-cat.svg';
      case 'Epic':
        return '/src/assets/cats/epic-cat.svg';
      case 'Legendary':
        return '/src/assets/cats/legendary-cat.svg';
      case 'Mythic':
        return '/src/assets/cats/mythic-cat.svg';
      default:
        return '/src/assets/cats/common-cat.svg';
    }
  };

  return (
    <Card className={cn("border-2 transition-all hover:shadow-lg", getRarityColor())}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle>{cat.name}</CardTitle>
          <span className={cn("px-2 py-0.5 rounded text-xs font-medium", getRarityBadgeColor())}>
            {cat.rarity}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex justify-center mb-4">
          <svg className="w-40 h-40" viewBox="0 0 100 100">
            <use href={`${getSvgPath()}#cat`} />
          </svg>
        </div>
        <div className="text-center">
          <div className="text-sm">Earnings:</div>
          <div className="font-bold text-lg">{cat.earnPerDay.toFixed(4)} TON/day</div>
        </div>
      </CardContent>
      <CardFooter className="text-xs text-gray-500 flex justify-center">
        <p>Acquired on {new Date(cat.acquiredAt).toLocaleDateString()}</p>
      </CardFooter>
    </Card>
  );
};

export default Cat;
