import React from 'react';
import { useGameStore } from '@/lib/stores/useGameStore';
import { cn } from '@/lib/utils';
import { Button } from '../ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../ui/tooltip';
import { useAudio } from '@/lib/stores/useAudio';
import { toast } from 'sonner';
import { getEggData } from '@/lib/gameData';

interface EggProps {
  type: string;
  onOpenEgg: (eggType: string) => void;
}

const Egg: React.FC<EggProps> = ({ type, onOpenEgg }) => {
  const eggData = getEggData(type);
  const balance = useGameStore((state) => state.balance);
  const purchaseEgg = useGameStore((state) => state.purchaseEgg);
  const playHit = useAudio((state) => state.playHit);
  
  const handleBuyEgg = () => {
    if (balance < eggData.price) {
      toast.error("Not enough TON to purchase this egg!");
      return;
    }
    
    playHit();
    if (purchaseEgg(type)) {
      onOpenEgg(type);
    }
  };

  const getSvgPath = () => {
    switch (type) {
      case 'mini':
        return '/src/assets/eggs/mini-egg.svg';
      case 'starter':
        return '/src/assets/eggs/starter-egg.svg';
      case 'pro':
        return '/src/assets/eggs/pro-egg.svg';
      case 'genesis':
        return '/src/assets/eggs/genesis-egg.svg';
      default:
        return '/src/assets/eggs/mini-egg.svg';
    }
  };

  // Helper to generate unique styles for different egg types
  const getEggStyles = () => {
    switch (type) {
      case 'mini':
        return {
          bgGradient: 'from-blue-50 to-blue-100',
          borderColor: 'border-blue-200',
          shadow: 'shadow-blue-100',
          button: 'from-blue-500 to-blue-600',
          title: 'from-blue-600 to-blue-500'
        };
      case 'starter':
        return {
          bgGradient: 'from-green-50 to-green-100',
          borderColor: 'border-green-200',
          shadow: 'shadow-green-100',
          button: 'from-green-500 to-green-600',
          title: 'from-green-600 to-green-500'
        };
      case 'pro':
        return {
          bgGradient: 'from-purple-50 to-purple-100',
          borderColor: 'border-purple-200',
          shadow: 'shadow-purple-100',
          button: 'from-purple-500 to-purple-600',
          title: 'from-purple-600 to-purple-500'
        };
      case 'genesis':
        return {
          bgGradient: 'from-amber-50 to-amber-100',
          borderColor: 'border-amber-200',
          shadow: 'shadow-amber-100',
          button: 'from-amber-500 to-amber-600',
          title: 'from-amber-600 to-amber-500'
        };
      default:
        return {
          bgGradient: 'from-gray-50 to-gray-100',
          borderColor: 'border-gray-200',
          shadow: 'shadow-gray-100',
          button: 'from-gray-500 to-gray-600',
          title: 'from-gray-600 to-gray-500'
        };
    }
  };
  
  const styles = getEggStyles();

  return (
    <Card 
      className={cn(
        "border rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-lg", 
        `bg-gradient-to-b ${styles.bgGradient}`,
        `border-2 ${styles.borderColor}`,
        `shadow-md ${styles.shadow}`
      )}
    >
      <CardHeader className="pb-2">
        <CardTitle className={`text-center capitalize text-lg font-bold bg-gradient-to-r ${styles.title} bg-clip-text text-transparent`}>
          {type} Egg
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center p-4">
        <div className="mb-3 p-4 flex justify-center">
          <svg className="w-32 h-32 drop-shadow-md transform transition-transform hover:rotate-12" viewBox="0 0 100 100">
            <use href={getSvgPath() + "#egg"} />
          </svg>
        </div>
        <div className="text-center space-y-2 mb-4 bg-white/60 p-3 rounded-lg w-full">
          <div className="font-bold text-lg">{eggData.price} TON</div>
          <div className="text-sm text-gray-600">
            Earn range: {eggData.minEarn} - {eggData.maxEarn} TON/day
          </div>
        </div>
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="w-full bg-white/70 backdrop-blur-sm h-8 rounded-full overflow-hidden shadow-inner border border-white">
                <div className="text-xs flex items-center justify-center h-full relative">
                  <span className="relative z-10 text-gray-800 font-semibold">View Rarity Chances</span>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent className="p-0 max-w-xs rounded-lg border-none shadow-xl bg-white/90 backdrop-blur-md">
              <div className="p-3">
                <h4 className="font-bold text-sm mb-2 text-gray-700">Rarity Chances</h4>
                <ul className="space-y-1.5 text-xs">
                  {eggData.cats.map((cat) => (
                    <li key={cat.name} className="flex justify-between items-center">
                      <span className="font-medium text-gray-700">{cat.name} ({cat.rarity}):</span>
                      <span className="bg-gray-100 px-2 py-0.5 rounded-full text-gray-700 font-medium">{cat.chance}%</span>
                    </li>
                  ))}
                </ul>
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </CardContent>
      <CardFooter className="flex justify-center pb-4">
        <Button 
          onClick={handleBuyEgg} 
          disabled={balance < eggData.price}
          className={`rounded-full px-6 bg-gradient-to-r ${styles.button} border-0 text-white hover:opacity-90 transition-all`}
        >
          Buy Egg
        </Button>
      </CardFooter>
    </Card>
  );
};

export default Egg;
