import React, { useState, useEffect } from 'react';
import { useAudio } from '@/lib/stores/useAudio';
import { useGameStore } from '@/lib/stores/useGameStore';
import { Button } from '../ui/button';
import { Cat as CatType } from '@/lib/stores/useGameStore';

interface EggOpeningAnimationProps {
  eggType: string;
  onComplete: () => void;
}

const EggOpeningAnimation: React.FC<EggOpeningAnimationProps> = ({ eggType, onComplete }) => {
  const [animationState, setAnimationState] = useState<'shaking' | 'cracking' | 'revealing' | 'complete'>('shaking');
  const [newCat, setNewCat] = useState<CatType | null>(null);
  
  const playHit = useAudio((state) => state.playHit);
  const playSuccess = useAudio((state) => state.playSuccess);
  const revealCat = useGameStore((state) => state.revealCat);

  useEffect(() => {
    // Start the animation sequence
    const shakingTimer = setTimeout(() => {
      playHit();
      setAnimationState('cracking');
      
      setTimeout(() => {
        // Open the egg and get a cat
        const cat = revealCat(eggType);
        setNewCat(cat);
        setAnimationState('revealing');
        playSuccess();
        
        setTimeout(() => {
          setAnimationState('complete');
        }, 1000);
      }, 1500);
    }, 2000);
    
    return () => {
      clearTimeout(shakingTimer);
    };
  }, [eggType, playHit, playSuccess, revealCat]);

  const getSvgPath = () => {
    switch (eggType) {
      case 'mini':
        return '/src/assets/eggs/mini-egg.svg';
      case 'starter':
        return '/src/assets/eggs/starter-egg.svg';
      case 'pro':
        return '/src/assets/eggs/pro-egg.svg';
      case 'genesis':
        return '/src/assets/eggs/genesis-egg.svg';
      default:
        return '/src/assets/eggs/mini-egg.svg';
    }
  };

  const getCatSvgPath = () => {
    if (!newCat) return '';
    
    switch (newCat.rarity) {
      case 'Common':
        return '/src/assets/cats/common-cat.svg';
      case 'Rare':
        return '/src/assets/cats/rare-cat.svg';
      case 'Epic':
        return '/src/assets/cats/epic-cat.svg';
      case 'Legendary':
        return '/src/assets/cats/legendary-cat.svg';
      case 'Mythic':
        return '/src/assets/cats/mythic-cat.svg';
      default:
        return '/src/assets/cats/common-cat.svg';
    }
  };

  const getRarityColor = () => {
    if (!newCat) return '';
    
    switch (newCat.rarity) {
      case 'Common':
        return 'text-gray-700';
      case 'Rare':
        return 'text-blue-600';
      case 'Epic':
        return 'text-purple-600';
      case 'Legendary':
        return 'text-amber-500';
      case 'Mythic':
        return 'text-rose-500';
      default:
        return 'text-gray-700';
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/80 z-50">
      <div className="bg-white rounded-xl p-8 max-w-md w-full text-center">
        {animationState === 'shaking' && (
          <>
            <h2 className="text-2xl font-bold mb-6">Opening Your Egg!</h2>
            <div className="flex justify-center mb-8">
              <svg className="w-40 h-40 animate-[wiggle_0.5s_ease-in-out_infinite]" viewBox="0 0 100 100">
                <use href={`${getSvgPath()}#egg`} />
              </svg>
            </div>
            <p className="text-gray-500">Your egg is about to hatch...</p>
          </>
        )}
        
        {animationState === 'cracking' && (
          <>
            <h2 className="text-2xl font-bold mb-6">The Egg Is Cracking!</h2>
            <div className="flex justify-center mb-8">
              <svg className="w-40 h-40 animate-pulse" viewBox="0 0 100 100">
                <use href={`${getSvgPath()}#egg-cracked`} />
              </svg>
            </div>
            <p className="text-gray-500">Something's coming out...</p>
          </>
        )}
        
        {(animationState === 'revealing' || animationState === 'complete') && newCat && (
          <>
            <h2 className="text-2xl font-bold mb-2">
              You Got a {newCat.rarity} Cat!
            </h2>
            <h3 className={`text-xl ${getRarityColor()} mb-6`}>{newCat.name}</h3>
            
            <div className="flex justify-center mb-6">
              <div className={`relative ${animationState === 'revealing' ? 'animate-bounce' : ''}`}>
                <svg className="w-48 h-48" viewBox="0 0 100 100">
                  <use href={`${getCatSvgPath()}#cat`} />
                </svg>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <p className="font-medium">Earnings: <span className="font-bold text-green-600">{newCat.earnPerDay.toFixed(4)} TON/day</span></p>
            </div>
            
            {animationState === 'complete' && (
              <Button onClick={onComplete} size="lg">
                Continue
              </Button>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default EggOpeningAnimation;
