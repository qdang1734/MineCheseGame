import { TonConnectUI } from '@tonconnect/ui';

// Configure the TON Connect UI instance with error handling
export const tonConnectUI = new TonConnectUI({
  manifestUrl: '/tonconnect-manifest.json',
  walletsListConfiguration: {
    includeWallets: ["tonkeeper", "tonhub"],
    excludeWallets: []
  }
});

// Add error handling
tonConnectUI.onStatusChange((wallet) => {
  if (wallet) {
    console.log('TON Connect connection restored');
  }
});

// Error handling
tonConnectUI.uiOptions = {
  loadingIndicator: true,
  retryPeriod: 3000,
};

// Options for withdrawing TON
export const withdrawOptions = {
  gasAmount: 0.1, // Estimated gas for a simple transfer
  jettonTransferGasAmount: 0.15 // Estimated gas for a jetton transfer
};