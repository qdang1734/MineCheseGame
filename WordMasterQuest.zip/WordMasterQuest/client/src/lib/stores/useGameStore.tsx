import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { getEggData } from '../gameData';

// Define Cat type for the game
export interface Cat {
  id: string;
  name: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
  earnPerDay: number;
  acquiredAt: number;
  eggType: string;
}

// Interface for the store state
interface GameState {
  // Player data
  balance: number;
  totalEarnings: number;
  cats: Cat[];
  eggsOpened: Record<string, number>;
  
  // Actions
  addBalance: (amount: number) => void;
  purchaseEgg: (eggType: string) => boolean;
  revealCat: (eggType: string) => Cat;
  addEarnings: (amount: number) => void;
}

// Create persistent game store
export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      // Initial state
      balance: 10, // Start with 10 TON for testing
      totalEarnings: 0,
      cats: [],
      eggsOpened: {
        mini: 0,
        starter: 0,
        pro: 0,
        genesis: 0
      },
      
      // Add funds to balance
      addBalance: (amount) => set((state) => ({ 
        balance: state.balance + amount 
      })),
      
      // Purchase an egg
      purchaseEgg: (eggType) => {
        const { balance } = get();
        const eggData = getEggData(eggType);
        
        if (balance < eggData.price) {
          return false;
        }
        
        set((state) => ({ 
          balance: state.balance - eggData.price,
          eggsOpened: {
            ...state.eggsOpened,
            [eggType]: (state.eggsOpened[eggType] || 0) + 1
          }
        }));
        
        return true;
      },
      
      // Reveal a cat from an egg
      revealCat: (eggType) => {
        const eggData = getEggData(eggType);
        
        // Determine cat rarity based on chance percentages
        const rand = Math.random() * 100;
        let cumulativeChance = 0;
        let selectedCat = eggData.cats[0]; // Default to first cat
        
        for (const cat of eggData.cats) {
          cumulativeChance += cat.chance;
          if (rand <= cumulativeChance) {
            selectedCat = cat;
            break;
          }
        }
        
        // Create a new cat instance
        const newCat: Cat = {
          id: Date.now().toString(),
          name: selectedCat.name,
          rarity: selectedCat.rarity as Cat['rarity'],
          earnPerDay: selectedCat.earnPerDay,
          acquiredAt: Date.now(),
          eggType: eggType
        };
        
        // Add cat to collection
        set((state) => ({
          cats: [...state.cats, newCat],
          totalEarnings: state.totalEarnings + newCat.earnPerDay
        }));
        
        return newCat;
      },
      
      // Add earnings to balance
      addEarnings: (amount) => set((state) => ({ 
        balance: state.balance + amount 
      })),
    }),
    {
      name: 'ton-cat-game', // local storage key
    }
  )
);
