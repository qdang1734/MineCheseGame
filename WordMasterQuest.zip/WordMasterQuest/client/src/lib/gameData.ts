// Game data for cat egg types, chances, and earnings

interface CatData {
  name: string;
  rarity: string;
  earnPerDay: number;
  chance: number;
}

interface EggData {
  price: number;
  minEarn: number;
  maxEarn: number;
  cats: CatData[];
}

interface GameData {
  eggs: Record<string, EggData>;
}

const gameData: GameData = {
  eggs: {
    mini: {
      price: 0.1,
      minEarn: 0.0001,
      maxEarn: 0.1,
      cats: [
        {
          name: "Fluffy",
          rarity: "Common",
          earnPerDay: 0.0002,
          chance: 40
        },
        {
          name: "Meowster",
          rarity: "Common",
          earnPerDay: 0.0005,
          chance: 35
        },
        {
          name: "Stripey",
          rarity: "Rare",
          earnPerDay: 0.0035,
          chance: 15
        },
        {
          name: "Luna",
          rarity: "Epic",
          earnPerDay: 0.01,
          chance: 7
        },
        {
          name: "Glitch",
          rarity: "Epic",
          earnPerDay: 0.02,
          chance: 2
        },
        {
          name: "Phantom",
          rarity: "Legendary",
          earnPerDay: 0.1,
          chance: 1
        }
      ]
    },
    starter: {
      price: 1,
      minEarn: 0.001,
      maxEarn: 0.5,
      cats: [
        {
          name: "Tofu",
          rarity: "Common",
          earnPerDay: 0.002,
          chance: 35
        },
        {
          name: "Boba",
          rarity: "Common",
          earnPerDay: 0.005,
          chance: 30
        },
        {
          name: "Ash",
          rarity: "Rare",
          earnPerDay: 0.035,
          chance: 15
        },
        {
          name: "Miso",
          rarity: "Epic",
          earnPerDay: 0.1,
          chance: 10
        },
        {
          name: "Orion",
          rarity: "Epic",
          earnPerDay: 0.2,
          chance: 5
        },
        {
          name: "Phantom",
          rarity: "Legendary",
          earnPerDay: 0.1,
          chance: 3
        },
        {
          name: "Crystal",
          rarity: "Legendary",
          earnPerDay: 0.35,
          chance: 2
        }
      ]
    },
    pro: {
      price: 10,
      minEarn: 0.01,
      maxEarn: 1,
      cats: [
        {
          name: "Biscuit",
          rarity: "Common",
          earnPerDay: 0.015,
          chance: 30
        },
        {
          name: "Mochi",
          rarity: "Common",
          earnPerDay: 0.025,
          chance: 25
        },
        {
          name: "Onyx",
          rarity: "Rare",
          earnPerDay: 0.075,
          chance: 20
        },
        {
          name: "Salem",
          rarity: "Rare",
          earnPerDay: 0.15,
          chance: 15
        },
        {
          name: "Nebula",
          rarity: "Epic",
          earnPerDay: 0.3,
          chance: 5
        },
        {
          name: "Nova",
          rarity: "Legendary",
          earnPerDay: 0.5,
          chance: 4
        },
        {
          name: "Cosmo",
          rarity: "Mythic",
          earnPerDay: 1,
          chance: 1
        }
      ]
    },
    genesis: {
      price: 100,
      minEarn: 0.1,
      maxEarn: 10,
      cats: [
        {
          name: "Peanut",
          rarity: "Rare",
          earnPerDay: 0.1,
          chance: 25
        },
        {
          name: "Ginger",
          rarity: "Rare",
          earnPerDay: 0.2,
          chance: 20
        },
        {
          name: "Midnight",
          rarity: "Epic",
          earnPerDay: 0.5,
          chance: 15
        },
        {
          name: "Aurora",
          rarity: "Epic",
          earnPerDay: 1,
          chance: 10
        },
        {
          name: "Galaxy",
          rarity: "Legendary",
          earnPerDay: 2,
          chance: 20
        },
        {
          name: "Infinity",
          rarity: "Legendary",
          earnPerDay: 5,
          chance: 9
        },
        {
          name: "Quantum",
          rarity: "Mythic",
          earnPerDay: 10,
          chance: 1
        }
      ]
    }
  }
};

export function getEggData(eggType: string): EggData {
  return gameData.eggs[eggType] || gameData.eggs.mini;
}

export default gameData;
