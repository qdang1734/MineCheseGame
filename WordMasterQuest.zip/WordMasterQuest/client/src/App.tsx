import { QueryClientProvider } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "sonner";
import GameBoard from "./components/game/GameBoard";
import "@fontsource/inter";
import "./index.css";
import { useAudio } from "./lib/stores/useAudio";

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const setBackgroundMusic = useAudio((state) => state.setBackgroundMusic);
  const setHitSound = useAudio((state) => state.setHitSound);
  const setSuccessSound = useAudio((state) => state.setSuccessSound);

  useEffect(() => {
    // Preload all sounds
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    const hitSfx = new Audio("/sounds/hit.mp3");
    setHitSound(hitSfx);

    const successSfx = new Audio("/sounds/success.mp3");
    setSuccessSound(successSfx);

    // Simulate loading resources
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => {
      clearTimeout(timer);
      bgMusic.pause();
      hitSfx.pause();
      successSfx.pause();
    };
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="w-full h-full">
        {isLoading ? (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-700 to-blue-500">
            <div className="text-center bg-white/10 backdrop-blur-md p-8 rounded-2xl shadow-xl">
              <div className="w-20 h-20 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
              <h1 className="text-2xl font-bold text-white">Loading Cats...</h1>
              <p className="text-white/70 mt-2">Preparing your fluffy companions</p>
            </div>
          </div>
        ) : (
          <GameBoard />
        )}
      </div>
      <Toaster position="top-right" theme="light" />
    </QueryClientProvider>
  );
}

export default App;
