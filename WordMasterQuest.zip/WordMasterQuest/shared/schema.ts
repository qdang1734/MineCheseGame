import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  balance: decimal("balance", { precision: 16, scale: 6 }).notNull().default("10"),
  totalEarnings: decimal("total_earnings", { precision: 16, scale: 6 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Cats table
export const cats = pgTable("cats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  rarity: text("rarity").notNull(),
  earnPerDay: decimal("earn_per_day", { precision: 16, scale: 6 }).notNull(),
  eggType: text("egg_type").notNull(),
  acquiredAt: timestamp("acquired_at").notNull().defaultNow(),
});

// Eggs history table
export const eggsOpened = pgTable("eggs_opened", {
  id: serial("id").primaryKey(),
  eggType: text("egg_type").notNull(),
  count: integer("count").notNull().default(1),
  userId: integer("user_id").notNull().references(() => users.id),
});

// Egg opening history table
export const eggsHistory = pgTable("eggs_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  eggType: text("egg_type").notNull(),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCatSchema = createInsertSchema(cats).pick({
  userId: true,
  name: true,
  rarity: true,
  earnPerDay: true,
  eggType: true,
});

export const insertEggOpenedSchema = createInsertSchema(eggsOpened).pick({
  userId: true,
  eggType: true,
  count: true,
});

export const insertEggHistorySchema = createInsertSchema(eggsHistory).pick({
  userId: true,
  eggType: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCat = z.infer<typeof insertCatSchema>;
export type Cat = typeof cats.$inferSelect;

export type InsertEggOpened = z.infer<typeof insertEggOpenedSchema>;
export type EggOpened = typeof eggsOpened.$inferSelect;

export type InsertEggHistory = z.infer<typeof insertEggHistorySchema>;
export type EggHistory = typeof eggsHistory.$inferSelect;
