
import TelegramBot from 'node-telegram-bot-api';

const token = process.env.TELEGRAM_BOT_TOKEN || '';
const bot = new TelegramBot(token, { polling: true });

export function initTelegramBot(baseUrl: string) {
  // Welcome message with emoji and formatting
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const welcomeMessage = `
🎮 *Welcome to TON Cat Eggs Game!*

Click the Play button below to start your adventure!

🎯 *Available Commands:*
/start - Start playing
/help - Show commands
/stats - View game stats

Join the fun and start collecting cats! 😺
    `;
    
    bot.sendMessage(chatId, welcomeMessage, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [[
          { text: '🎮 Play Now!', callback_data: 'play_game' }
        ]]
      }
    });
  });

  // Handle play button click
  bot.on('callback_query', (query) => {
    if (query.data === 'play_game') {
      bot.answerCallbackQuery(query.id);
      bot.sendMessage(query.message.chat.id, `
🎮 *Let's Play!*

Click here to start playing: ${baseUrl}

Have fun collecting cats! 🐱
      `, { parse_mode: 'Markdown' });
    }
  });

  // Help command with better formatting
  bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    const helpMessage = `
📖 *Game Commands:*

🎮 /start - Begin your adventure
📊 /stats - View game statistics
❓ /help - Show this help message

Need help? Feel free to ask! 🤝
    `;
    
    bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
  });

  // Stats command with error handling
  bot.onText(/\/stats/, async (msg) => {
    const chatId = msg.chat.id;
    try {
      const response = await fetch(`${baseUrl}/api/stats`);
      const stats = await response.json();
      const statsMessage = `
📊 *Game Statistics*

👥 Total Players: ${stats.totalPlayers || 0}
🥚 Total Eggs: ${stats.totalEggs || 0}

Keep playing to improve your stats! 🎯
      `;
      
      bot.sendMessage(chatId, statsMessage, { parse_mode: 'Markdown' });
    } catch (error) {
      bot.sendMessage(chatId, '⚠️ Could not fetch statistics at the moment. Please try again later!', { parse_mode: 'Markdown' });
    }
  });

  // Error handling for bot
  bot.on('polling_error', (error) => {
    console.error('Telegram Bot polling error:', error);
  });

  console.log('✨ Telegram bot initialized successfully!');
}
